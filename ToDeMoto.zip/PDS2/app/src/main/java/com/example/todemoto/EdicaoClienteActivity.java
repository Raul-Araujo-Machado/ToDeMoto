package com.example.todemoto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EdicaoClienteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edicao_cliente);
    }
}